var loginStatus=false;

function changeStatus(){
    window.location.href='./index.html'
    return loginStatus=true;
}